VERSION = (0, 1, 0, 'pre')

def get_version():
    return '%s.%s.%s-%s' % VERSION